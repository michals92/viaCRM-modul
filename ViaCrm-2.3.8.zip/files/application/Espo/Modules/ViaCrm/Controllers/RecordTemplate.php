<?php

namespace Espo\Modules\ViaCrm\Controllers;

use Espo\Core\Api\Request;
use Espo\Core\Api\Response;

class RecordTemplate extends \Espo\Core\Templates\Controllers\Base 
{
    public function actionCreateSample(Request $request, Response $response): array
    {
        if (!$this->user->isAdmin()) {
            throw new \Espo\Core\Exceptions\Forbidden('Admin access required');
        }
        
        try {
            $entityManager = $this->getEntityManager();
            
            // Create sample record template
            $template = $entityManager->createEntity('RecordTemplate', [
                'name' => 'Sample Template - ' . date('Y-m-d H:i:s'),
                'description' => 'This is a test template created by ViaCRM module',
                'entityType' => 'Account',
                'data' => json_encode([
                    'type' => 'Customer',
                    'industry' => 'Technology'
                ]),
                'isActive' => true,
                'isGlobal' => true
            ]);
            
            return [
                'success' => true,
                'id' => $template->getId(),
                'name' => $template->get('name')
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}