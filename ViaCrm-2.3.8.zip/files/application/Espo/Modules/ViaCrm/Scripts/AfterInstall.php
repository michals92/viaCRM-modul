<?php

namespace Espo\Modules\ViaCrm\Scripts;

use Espo\Core\Container;

class AfterInstall
{
    private $container;
    
    public function run(Container $container): void
    {
        $this->container = $container;
        $entityManager = $container->get('entityManager');
        $pdo = $entityManager->getPDO();
        
        // Create Alert table if not exists
        $alertTableSql = "
        CREATE TABLE IF NOT EXISTS `alert` (
            `id` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
            `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `deleted` tinyint(1) DEFAULT '0',
            `description` mediumtext COLLATE utf8mb4_unicode_ci,
            `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Info',
            `priority` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
            `status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
            `icon_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'fas fa-info-circle',
            `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#17a2b8',
            `date_start` datetime DEFAULT NULL,
            `date_end` datetime DEFAULT NULL,
            `url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `is_closable` tinyint(1) DEFAULT '1',
            `is_global` tinyint(1) DEFAULT '0',
            `created_at` datetime DEFAULT NULL,
            `modified_at` datetime DEFAULT NULL,
            `created_by_id` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `modified_by_id` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `assigned_user_id` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `IDX_CREATED_BY_ID` (`created_by_id`),
            KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
            KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
            KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
            KEY `IDX_STATUS` (`status`,`deleted`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";
        
        $pdo->exec($alertTableSql);
        
        // Create RecordTemplate table if not exists
        $templateTableSql = "
        CREATE TABLE IF NOT EXISTS `record_template` (
            `id` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
            `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `deleted` tinyint(1) DEFAULT '0',
            `entity_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `description` mediumtext COLLATE utf8mb4_unicode_ci,
            `data` mediumtext COLLATE utf8mb4_unicode_ci,
            `is_active` tinyint(1) DEFAULT '1',
            `is_global` tinyint(1) DEFAULT '0',
            `created_at` datetime DEFAULT NULL,
            `modified_at` datetime DEFAULT NULL,
            `created_by_id` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `modified_by_id` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            `assigned_user_id` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `IDX_CREATED_BY_ID` (`created_by_id`),
            KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
            KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
            KEY `IDX_ENTITY_TYPE` (`entity_type`,`deleted`),
            KEY `IDX_CREATED_AT` (`created_at`,`deleted`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";
        
        $pdo->exec($templateTableSql);
        
        // Insert sample data for Alert
        $alertData = [
            ['id' => $this->generateId(), 'name' => 'Welcome to ViaCRM', 'description' => 'Welcome alert', 'type' => 'Info', 'status' => 'Active', 'is_global' => 1],
            ['id' => $this->generateId(), 'name' => 'Module Installed', 'description' => 'Module installed successfully', 'type' => 'Success', 'status' => 'Active', 'is_global' => 1]
        ];
        
        foreach ($alertData as $alert) {
            $sql = "INSERT IGNORE INTO `alert` (id, name, description, type, status, is_global, created_at) 
                    VALUES (:id, :name, :description, :type, :status, :is_global, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($alert);
        }
        
        // Insert sample data for RecordTemplate
        $templateData = [
            ['id' => $this->generateId(), 'name' => 'Account Template', 'entity_type' => 'Account', 'description' => 'Basic account template', 'data' => '{"type":"Customer"}', 'is_active' => 1, 'is_global' => 1],
            ['id' => $this->generateId(), 'name' => 'Lead Template', 'entity_type' => 'Lead', 'description' => 'Basic lead template', 'data' => '{"status":"New"}', 'is_active' => 1, 'is_global' => 1]
        ];
        
        foreach ($templateData as $template) {
            $sql = "INSERT IGNORE INTO `record_template` (id, name, entity_type, description, data, is_active, is_global, created_at) 
                    VALUES (:id, :name, :entity_type, :description, :data, :is_active, :is_global, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($template);
        }
    }
    
    private function generateId(): string
    {
        return substr(md5(uniqid(mt_rand(), true)), 0, 17);
    }
}